
package ejercicio_actividad_4;


public interface Estado {
    
     String displaySongDetail(Estado song);
     
}
